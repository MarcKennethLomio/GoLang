package models 

type Person struct{
	Name string
}

func (e *Person) PersonName() string {
	return e.Name
}