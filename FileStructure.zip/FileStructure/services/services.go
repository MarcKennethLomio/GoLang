package services

import  (
	models "models"
)


func ShowPersonName(){
	person := models.Person{
		Name: "Marc Kenneth Lomio",
	}

	println(person.PersonName())
}